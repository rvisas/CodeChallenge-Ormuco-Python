# CodeChallenge-Ormuco-Python
Solution for a question on LRU distributed cache
